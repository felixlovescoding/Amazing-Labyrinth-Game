package View;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

import Controller.LabyrinthController;
import Model.Card;
import Model.Player;
import Model.Tile;

import javax.swing.*;

public class LabyrinthStartFrame extends JFrame {

	// Fields
	// Array that holds all the tiles that should but do not exist on the board
	private ArrayList<Tile> tilesNotOnBoard = new ArrayList<>();;
	// Array that holds the cards of all players
	private static ArrayList<Card> cards = new ArrayList<>();;
	// Game board
	private Tile tileBoardMatrix[][] = new Tile[7][7];
	// Buttons
	private JButton playGame; // play a new game
	private JButton playSavedGame; // play from a save file
	private Tile freeTile;
	//private String[] playerImagePath = { "images/hussain.png", "images/frank.png", "images/june.png",
		//	"images/aaron.png" };
	private Player[] players = new Player[4];
	private String[] numberOfCards = { "6", "5", "4", "3", "2", "1" };
	private JComboBox cardsAGame = new JComboBox(numberOfCards);
	private boolean free;

	// Constructor
	public LabyrinthStartFrame() {

		this.setName("Labyrinth Start!");
		this.setSize(900, 500);
		this.setResizable(false);
		this.setLayout(null);
		this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		this.setVisible(true);

		// Create the buttons in the start page
		createComponents();

	}

	// Frank
	// Creates the components in the Start Frame
	private void createComponents() {

		playGame = new JButton("Play!");
		playGame.setBounds(100, 100, 200, 100);
		this.add(playGame);

		playSavedGame = new JButton("Play Saved Game!");
		playSavedGame.setBounds(400, 100, 200, 100);
		this.add(playSavedGame);

		cardsAGame.setBounds(100, 300, 100, 40);
		this.add(cardsAGame);
	}

	// Frank
	// Method that creates the board
	public void createBoard(String path) {

		// Fill the board with blank tiles
		fillBoard();
		// Load board and find out how many tiles must be creates
		int num = loadBoard(path);
		// Create the missing tiles
		createTiles(num);
		// Add tiles to the board
		addTiles();

		// Will delete
		// display();
	}

	// Frank
	// Fills Board with blank tiles
	private void fillBoard() {

		for (int i = 0; i < 7; i++) {

			for (int j = 0; j < 7; j++) {

				tileBoardMatrix[i][j] = new Tile("blank");
			}
		}

	}

	// Frank
	// Loads the board from a save file or the original file
	// Returns the number of tiles that have been added onto the board
	private int loadBoard(String path) {

		// Counts how many tiles have been loaded onto the board
		int counter = 0;
		try {

			// Read information from the file
			Scanner input = new Scanner(new File(path));

			String[] lineInfo;

			// Get information
			while (input.hasNextLine()) {

				// Get information on the tile
				lineInfo = input.nextLine().split(",");
				String name = lineInfo[0];
				char pieceType = Character.toUpperCase(lineInfo[1].charAt(0));
				int rotation = Integer.parseInt(lineInfo[2]);
				int row = Integer.parseInt(lineInfo[4]);
				int column = Integer.parseInt(lineInfo[5]);

				// Check if the tile has been given a rotation
				if (rotation < 0) {

					// Give tile a rotation
					rotation = LabyrinthController.randomInt(0, 3);
				}

				// Check player number
				if (name.equals("Player0")) {
					players[0] = new Player(row, column, LabyrinthBoardPanel.getImg("images/hussain.png"));
					players[0].setTreasuresFound(rotation);
					continue;
				} else if (name.equals("Player1")) {
					players[1] = new Player(row, column, LabyrinthBoardPanel.getImg("images/frank.png"));
					players[1].setTreasuresFound(rotation);
					continue;
				} else if (name.equals("Player2")) {
					players[2] = new Player(row, column, LabyrinthBoardPanel.getImg("images/june.png"));
					players[2].setTreasuresFound(rotation);
					continue;
				} else if (name.equals("Player3")) {
					players[3] = new Player(row, column, LabyrinthBoardPanel.getImg("images/aaron.png"));
					players[3].setTreasuresFound(rotation);
					continue;
				}

				// Check if the tile exists on the board
				if (row == -1 || column == -1) {

					// Add tile to array
					tilesNotOnBoard.add(new Tile(name));
					tilesNotOnBoard.get(tilesNotOnBoard.size() - 1).setPieceType(pieceType);
					tilesNotOnBoard.get(tilesNotOnBoard.size() - 1).setRotation(rotation);
					continue;

				}

				if (row == -2 && column == -2) {
					freeTile = new Tile(name);
					freeTile.setRotation(rotation);
					freeTile.setPieceType(pieceType);
					counter--;
					free = true;
					continue;
				}

				// Redefine tile
				tileBoardMatrix[row][column].setName(name);
				tileBoardMatrix[row][column].setPieceType(pieceType);
				tileBoardMatrix[row][column].setRotation(rotation);

				// Add one to the counter
				counter++;
			}
		} catch (FileNotFoundException e) {

			// Error message
			System.out.println("Treasures file not found");
		}

		// Manually set the corner locations
		tileBoardMatrix[0][0].setName("L");
		tileBoardMatrix[0][0].setPieceType('L');
		tileBoardMatrix[0][0].setRotation(1);

		tileBoardMatrix[0][6].setName("L");
		tileBoardMatrix[0][6].setPieceType('L');
		tileBoardMatrix[0][6].setRotation(2);

		tileBoardMatrix[6][6].setName("L");
		tileBoardMatrix[6][6].setPieceType('L');
		tileBoardMatrix[6][6].setRotation(3);

		tileBoardMatrix[6][0].setName("L");
		tileBoardMatrix[6][0].setPieceType('L');
		tileBoardMatrix[6][0].setRotation(0);

		// Return the number of tiles that have been added to the board
		return counter;

	}

	// Frank
	// Method that creates missing tiles
	private void createTiles(int filled) {

		// Counter number of tiles that still needs to be created
		int tilesToCreate = 48 - filled - tilesNotOnBoard.size();
		for (int i = 0; i < tilesToCreate; i++) {

			// Get a random piece type
			char pieceType;
			if (LabyrinthController.randomInt(1, 2) == 1) {

				pieceType = 'L';
			} else {

				pieceType = 'I';
			}

			Tile tile = new Tile(String.valueOf(pieceType));
			tile.setPieceType(pieceType);
			int num = LabyrinthController.randomInt(0, 3);
			tile.setRotation(num);
			// Add tile into the tiles not on board array
			tilesNotOnBoard.add(tile);

		}

		// Shuffle the cards
		Collections.shuffle(tilesNotOnBoard);

		if (!free) {
			// Set the first tile to the free tile
			freeTile = (tilesNotOnBoard.get(0));
			tilesNotOnBoard.remove(0);
		}
	}

	// Frank
	// Method that fills in the rest of the board
	private void addTiles() {

		for (int i = 0; i < 7; i++) {

			for (int j = 0; j < 7; j++) {

				// Check if tile is blank
				if (tileBoardMatrix[i][j].getName().equals("blank")) {

					// fill tile
					tileBoardMatrix[i][j] = tilesNotOnBoard.get(0);
					tileBoardMatrix[i][j].setRow(i);
					tileBoardMatrix[i][j].setColumn(j);
					tilesNotOnBoard.remove(0);
				}
			}

		}

	}

	// Frank
	// Creates the cards from a save file or the original file
	// Returns the starting player
	public int createCards(String path) {

		int firstPlayer = -1;

		// Create cards
		try {
			Scanner input = new Scanner(new File(path));

			String[] cardInfo;

			// Get the starting player
			firstPlayer = Integer.parseInt(input.nextLine());

			// Load cards
			for (int i = 0; i < 24; i++) {

				// Read information from saved file
				String line = input.nextLine();
				cardInfo = line.split(",");

				// Create cards for player
				cards.add(new Card(cardInfo[0], Integer.parseInt(cardInfo[1]), Integer.parseInt(cardInfo[2])));
				cards.get(cards.size() - 1).setTreasure(Boolean.parseBoolean(cardInfo[3]));
				cards.get(cards.size() - 1).setPlayer(Integer.parseInt(cardInfo[4]));

			}

			// Close Scanner
			input.close();

		} catch (FileNotFoundException e) {

			System.out.println("Error Loading Cards");
		}

		// return the starting player
		return firstPlayer;
	}

	// Frank
	// Various Getters and Setters
	public JButton getPlayGame() {
		return playGame;
	}

	public void setPlayGame(JButton playGame) {
		this.playGame = playGame;
	}

	public JButton getPlaySavedGame() {
		return playSavedGame;
	}

	public void setPlaySavedGame(JButton playSavedGame) {
		this.playSavedGame = playSavedGame;
	}

	public static ArrayList<Card> getCards() {
		return cards;
	}

	public static void setCards(ArrayList<Card> cards) {
		LabyrinthStartFrame.cards = cards;
	}

	public Tile[][] getTileBoardMatrix() {
		return tileBoardMatrix;
	}

	public void setTileBoardMatrix(Tile[][] tileBoardMatrix) {
		this.tileBoardMatrix = tileBoardMatrix;
	}

	public Tile getFreeTile() {
		return freeTile;
	}

	public void setFreeTile(Tile freeTile) {
		this.freeTile = freeTile;
	}

	public Player[] getPlayers() {
		return players;
	}

	public void setPlayers(Player[] players) {
		this.players = players;
	}

	public JComboBox getCardsAGame() {
		return cardsAGame;
	}

	public void setCardsAGame(JComboBox cardsAGame) {
		this.cardsAGame = cardsAGame;
	}

}