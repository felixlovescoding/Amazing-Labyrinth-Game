package Application;

/*
 * project header
 */

import Controller.LabyrinthController;
public class LabyrinthApplication {

	
	public static void main(String[] args) {
	
		new LabyrinthController();
		 
	}
}
